
import requests
import time
import yaml
import concurrent.futures

# 配置参数
download_url = 'https://www.baidu.com/favicon.ico'  # 中国大陆测速用小文件下载地址
top_n = 30  # 选取前 N 个节点

# 1. 抓取免费代理列表（ProxyScrape API）
def fetch_proxies():
    url = 'https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=5000&country=CN'
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    return [line.strip() for line in resp.text.splitlines() if line.strip()]

# 2. 对单个代理进行测速，返回响应时间(ms)
def test_proxy(proxy):
    proxies = {
        'http': f'http://{proxy}',
        'https': f'http://{proxy}',
    }
    try:
        start = time.time()
        # 使用 GET 下载中国大陆小文件，测量总耗时
        resp = requests.get(download_url, proxies=proxies, timeout=5)
        resp.raise_for_status()
        elapsed = (time.time() - start) * 1000  # ms
        return proxy, elapsed
    except Exception:
        return proxy, float('inf')

# 3. 并发测速，筛选 Top N
def get_top_proxies(proxies, top_n=top_n):
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(test_proxy, p): p for p in proxies}
        for fut in concurrent.futures.as_completed(futures):
            proxy, latency = fut.result()
            if latency < float('inf'):
                results.append((proxy, latency))
    # 按延迟排序
    results.sort(key=lambda x: x[1])
    return [p for p, _ in results[:top_n]]

# 4. 生成 Clash 订阅 YAML
def generate_clash_yaml(selected_proxies):
    proxies = []
    for p in selected_proxies:
        ip, port = p.split(':')
        proxies.append({
            'name': f'{ip}:{port}',
            'type': 'http',
            'server': ip,
            'port': int(port),
            'tls': False
        })
    clash = {
        'proxies': proxies,
        'proxy-groups': [
            {
                'name': 'Auto-Proxy',
                'type': 'select',
                'proxies': [p['name'] for p in proxies]
            }
        ],
        'rules': ['MATCH,Auto-Proxy']
    }
    return yaml.dump(clash, sort_keys=False, allow_unicode=True)

# 5. 主流程
def main():
    print('Fetching China proxies...')
    proxies = fetch_proxies()
    print(f'Total proxies fetched: {len(proxies)}')

    print('Testing proxies against China endpoint...')
    top = get_top_proxies(proxies)
    print(f'Selected top {len(top)} proxies')

    sub_content = generate_clash_yaml(top)
    with open('clash_sub.yaml', 'w', encoding='utf-8') as f:
        f.write(sub_content)
    print('Clash subscription file generated: clash_sub.yaml')

if __name__ == '__main__':
    main()
